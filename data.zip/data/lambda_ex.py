import csv
import boto3
import pymysql

# MySQL connection parameters
HOST = '0.tcp.in.ngrok.io'
PORT=11588
USER = 'root'
PASSWORD = ''
DATABASE = 'world'

# S3 bucket and file name
BUCKET_NAME = 'lambda-ngrok'
FILE_NAME = 'exported_data.csv'

def lambda_handler(event, context):
    # Connect to MySQL
    conn = pymysql.connect(host=HOST, user=USER, password=PASSWORD, database=DATABASE,port=PORT)
    cursor = conn.cursor()

    # Execute MySQL query
    cursor.execute("SELECT * FROM city")

    # Fetch data
    data = cursor.fetchall()

    # Create CSV file
    with open('/tmp/' + FILE_NAME, 'w', newline='') as csvfile:
        csv_writer = csv.writer(csvfile)
        csv_writer.writerow([i[0] for i in cursor.description])  # Write headers
        csv_writer.writerows(data)

    # Upload CSV file to S3
    s3 = boto3.client('s3')
    s3.upload_file('/tmp/' + FILE_NAME, BUCKET_NAME, FILE_NAME)

    # Clean up
    conn.close()

    return {
        'statusCode': 200,
        'body': 'CSV file exported and uploaded to S3 successfully.'
    }
